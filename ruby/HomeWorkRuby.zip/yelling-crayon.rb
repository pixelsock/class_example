### This program asks user for their favorite Crayola crayon and then yells the answer back in all caps and in reverse. 

puts "What's your favorite Crayola crayon?"
answer = gets.chomp
puts answer.reverse.upcase